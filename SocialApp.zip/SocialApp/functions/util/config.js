module.exports = {
    apiKey: "AIzaSyCCrBO9FJ1BaxuffHlti4nx1BSH7samikw",
    authDomain: "reactnative-1daa2.firebaseapp.com",
    databaseURL: "https://reactnative-1daa2.firebaseio.com",
    projectId: "reactnative-1daa2",
    storageBucket: "reactnative-1daa2.appspot.com",
    messagingSenderId: "285119966849",
    appId: "1:285119966849:web:546c369598514df1e42780",
    measurementId: "G-XKJLJH2K67"
};
