// const admin = require('firebase-admin');

// admin.initializeApp();

// const db = admin.firestore();

// module.exports = { admin, db };


const admin = require('firebase-admin');

const serviceAccount = require("../serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  storageBucket: "reactnative-1daa2.appspot.com"
//  storageBucket: "https://reactnative-1daa2.firebaseio.com"

});

const db = admin.firestore();

module.exports = { admin, db };
